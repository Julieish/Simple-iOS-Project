//
//  NextViewController.swift
//  Trasmission
//
//  Created by 수현 on 2021/10/29.
//

import UIKit

class NextViewController: UIViewController {

    @IBOutlet weak var contentLbl: UILabel!
    var labelTxt: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let text = labelTxt {
            contentLbl.text = text
        } else {
            contentLbl.text = ""
        }
    }
    

    @IBAction func tapBackBtn(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    

}
