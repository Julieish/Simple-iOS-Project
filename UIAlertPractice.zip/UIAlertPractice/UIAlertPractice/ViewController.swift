//
//  ViewController.swift
//  UIAlertPractice
//
//  Created by 수현 on 2021/11/12.
//

import UIKit

class ViewController: UIViewController {
    let button = UIButton()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureBtn()
        self.view.addSubview(button)
        setBtnAutoLayout()
        
    }
    
    func configureBtn() {
        button.setTitle("Alert", for: .normal)
        button.setTitleColor(.black, for: .normal)
        button.layer.borderWidth = 1.0
        button.layer.cornerRadius = 20
        
        button.backgroundColor = .yellow
        button.addTarget(self, action: #selector(btnPressed), for: .touchUpInside)
    }
    
    func setBtnAutoLayout() {
        button.translatesAutoresizingMaskIntoConstraints = false
        button.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        button.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        button.heightAnchor.constraint(equalToConstant: 50).isActive = true
        button.widthAnchor.constraint(equalToConstant: 100).isActive = true
    }

    @objc func btnPressed() {
        let ac = UIAlertController(title: "this is title of alert", message: "this is message of alert", preferredStyle: .actionSheet)
        ac.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        ac.addAction(UIAlertAction(title: "cancel", style: .cancel, handler: nil))
        ac.addAction(UIAlertAction(title: "Go to yellow Screen", style: .destructive, handler: showYellowScreen))
        self.present(ac, animated: true, completion: nil)
    }
    
    func showYellowScreen(action: UIAlertAction!) {
        let nextVc = nextViewController()
        
        let navVc = UINavigationController(rootViewController: nextVc)
        navVc.modalPresentationStyle = .fullScreen
        present(navVc, animated: true, completion: nil)
    }
}

class nextViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "back", style: .plain, target: self, action: #selector(dismissScreen))
        
        title = "Yellow Screen"
        view.backgroundColor = .yellow
    }
    
    @objc private func dismissScreen() {
        dismiss(animated: true, completion: nil)
    }
}
