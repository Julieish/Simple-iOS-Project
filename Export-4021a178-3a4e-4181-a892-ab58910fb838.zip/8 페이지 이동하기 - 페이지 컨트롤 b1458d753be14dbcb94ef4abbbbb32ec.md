# 8. 페이지 이동하기 - 페이지 컨트롤

---

스토리 보드는 다음과 같이 구성했다. 화면을 거의 꽉 채우는 image View와 그 imageView위에 page control을 올려두었다. 위치는 가운데로 설정했다.

![8%20%E1%84%91%E1%85%A6%E1%84%8B%E1%85%B5%E1%84%8C%E1%85%B5%20%E1%84%8B%E1%85%B5%E1%84%83%E1%85%A9%E1%86%BC%E1%84%92%E1%85%A1%E1%84%80%E1%85%B5%20-%20%E1%84%91%E1%85%A6%E1%84%8B%E1%85%B5%E1%84%8C%E1%85%B5%20%E1%84%8F%E1%85%A5%E1%86%AB%E1%84%90%E1%85%B3%E1%84%85%E1%85%A9%E1%86%AF%20b1458d753be14dbcb94ef4abbbbb32ec/_2021-03-22__8.18.54.png](8%20%E1%84%91%E1%85%A6%E1%84%8B%E1%85%B5%E1%84%8C%E1%85%B5%20%E1%84%8B%E1%85%B5%E1%84%83%E1%85%A9%E1%86%BC%E1%84%92%E1%85%A1%E1%84%80%E1%85%B5%20-%20%E1%84%91%E1%85%A6%E1%84%8B%E1%85%B5%E1%84%8C%E1%85%B5%20%E1%84%8F%E1%85%A5%E1%86%AB%E1%84%90%E1%85%B3%E1%84%85%E1%85%A9%E1%86%AF%20b1458d753be14dbcb94ef4abbbbb32ec/_2021-03-22__8.18.54.png)

내가 좋아하는 고양이 이미지 총 19개를 "cat1.jpg", "cat2.jpg" 와 같은 이름으로 설정하고 Assets에 붙여넣었다.

UIImageView와 PageControl에 대한 아웃렛 변수를 만들고, Page Control에 대해서는 액션 함수도 만들었다.

```python
import UIKit

class ViewController: UIViewController {

    @IBOutlet var imgView: UIImageView!
    @IBOutlet var pageControl: UIPageControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func pageChange(_ sender: UIPageControl) {
    }
    
}
```

그리고 앞서 붙여넣은 고양이 이미지를 한 변수에 저장해두어야 하므로 고양이 이미지 이름을 String 타입의 배열에 저장했다.

```python
var images:[String] = [] //배열 선언
```

우선 배열을 선언해두고,

viewDidLoad 함수에서 이 배열에 모든 고양이 이미지 이름을 추가했다. 아래는 viewDidLoad 함수 내부의 코드이다.

```python
for i in 1..<19 {
            let name = "cat" + String(i) + ".jpg"
            images.append(name)
        }
```

액션 함수인 pageChange에서는 간단하게, 이미지 뷰의 이미지가 페이지 컨트롤에서 현재 페이지에 해당하는 사진을 보이게 하도록 설정했다.

```python
imgView.image = UIImage(named: images[pageControl.currentPage])
```

pageControl에 대한 초기 설정이 필요하기 때문에 viewDidLoad 함수에 추가로 작성해주었다.

```python
//pageControl의 페이지 개수를 이미지 배열의 크기로 설정
pageControl.numberOfPages = images.count

//pageControl의 현재 페이지를 가장 첫번째인 0으로 설정
pageControl.currentPage = 0

//pgaeControl의 현재 페이지를 제외한 동그라미 색깔 설정
pageControl.pageIndicatorTintColor = UIColor.green

//pageControl의 현재 페이지 동그라미 색깔 설정
pageControl.currentPageIndicatorTintColor = UIColor.red

//가장 처음 이미지를 가장 첫 번째 고양이 사진으로 설정
imgView.image = UIImage(named: images[0])
```

완성된 코드와 화면은 다음과 같다.

```python
import UIKit

class ViewController: UIViewController {

    @IBOutlet var imgView: UIImageView!
    @IBOutlet var pageControl: UIPageControl!
    var images:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        for i in 1..<19 {
            let name = "cat" + String(i) + ".jpg"
            images.append(name)
        }
        
        pageControl.numberOfPages = images.count
        pageControl.currentPage = 0
        pageControl.pageIndicatorTintColor = UIColor.green
        pageControl.currentPageIndicatorTintColor = UIColor.red
        imgView.image = UIImage(named: images[0])
    }

    @IBAction func pageChange(_ sender: UIPageControl) {
        imgView.image = UIImage(named: images[pageControl.currentPage])
    }
    
}
```

![8%20%E1%84%91%E1%85%A6%E1%84%8B%E1%85%B5%E1%84%8C%E1%85%B5%20%E1%84%8B%E1%85%B5%E1%84%83%E1%85%A9%E1%86%BC%E1%84%92%E1%85%A1%E1%84%80%E1%85%B5%20-%20%E1%84%91%E1%85%A6%E1%84%8B%E1%85%B5%E1%84%8C%E1%85%B5%20%E1%84%8F%E1%85%A5%E1%86%AB%E1%84%90%E1%85%B3%E1%84%85%E1%85%A9%E1%86%AF%20b1458d753be14dbcb94ef4abbbbb32ec/Untitled.png](8%20%E1%84%91%E1%85%A6%E1%84%8B%E1%85%B5%E1%84%8C%E1%85%B5%20%E1%84%8B%E1%85%B5%E1%84%83%E1%85%A9%E1%86%BC%E1%84%92%E1%85%A1%E1%84%80%E1%85%B5%20-%20%E1%84%91%E1%85%A6%E1%84%8B%E1%85%B5%E1%84%8C%E1%85%B5%20%E1%84%8F%E1%85%A5%E1%86%AB%E1%84%90%E1%85%B3%E1%84%85%E1%85%A9%E1%86%AF%20b1458d753be14dbcb94ef4abbbbb32ec/Untitled.png)