//
//  InsertViewController.swift
//  SendDataByProtocolPractice
//
//  Created by 수현 on 2021/11/13.
//

import UIKit

protocol sendDataDelegate {
    func updateLabelText(text: String)
}

class InsertViewController: UIViewController {
    
    var del: sendDataDelegate?
    @IBOutlet weak var tf: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "hello"
        // Do any additional setup after loading the view.
    }
    
    @IBAction func tapDoneBtn(_ sender: UIButton) {
        del?.updateLabelText(text: tf.text ?? "")
        navigationController?.popViewController(animated: true)
    }
    
    
}
