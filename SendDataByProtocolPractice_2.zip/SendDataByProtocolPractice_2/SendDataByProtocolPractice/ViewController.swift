//
//  ViewController.swift
//  SendDataByProtocolPractice
//
//  Created by 수현 on 2021/11/13.
//

import UIKit


class ViewController: UIViewController, sendDataDelegate {
    @IBOutlet weak var label: UILabel!
    
    func updateLabelText(text: String) {
        label.text = text
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToNext" {
            let vc = segue.destination as! InsertViewController
            vc.del = self
        }
    }


}

