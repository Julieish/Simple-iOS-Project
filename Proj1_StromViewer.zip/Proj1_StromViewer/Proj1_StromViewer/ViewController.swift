//
//  ViewController.swift
//  Proj1_StromViewer
//
//  Created by 수현 on 2021/11/04.
//

import UIKit

class ViewController: UIViewController {
    
    var contentNames = [String]()
    
    @IBOutlet var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        for i in 0..<10 {
            contentNames.append("nssl\(i+1)")
        }
    }


}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as? DetailViewController else { return }
        vc.modalPresentationStyle = .fullScreen
        vc.imageTitle = contentNames[indexPath.row]
        self.present(vc, animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Storm Viewer"
    }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        guard let header = view as? UITableViewHeaderFooterView else { return }
        header.textLabel?.font = UIFont.boldSystemFont(ofSize: 30)
        header.textLabel?.frame = header.bounds
        header.textLabel?.textColor = .black
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 140
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contentNames.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! CustomImageCell
        cell.contentNameLbl.text = contentNames[indexPath.row]
        cell.contentImg.image = UIImage(named: contentNames[indexPath.row]+".jpg")
        cell.accessoryType = .disclosureIndicator
        return cell
    }
    
    
}

class CustomImageCell: UITableViewCell {
    @IBOutlet var contentImg: UIImageView!
    @IBOutlet var contentNameLbl: UILabel!
}
