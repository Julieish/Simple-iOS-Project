//
//  DetailViewController.swift
//  Proj1_StromViewer
//
//  Created by 수현 on 2021/11/04.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var navigationBar: UINavigationBar!
    @IBOutlet weak var barBtnItem: UIBarButtonItem!
    @IBOutlet weak var image: UIImageView!
    
    var imageTitle: String?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.image.image = UIImage(named: imageTitle! + ".jpg")
        barBtnItem.title = "Back"
        navigationBar.topItem?.title = imageTitle ?? ""
    }
    @IBAction func tapBackBarBtn(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
    }
    
}
