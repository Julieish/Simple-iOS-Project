//
//  ViewController.swift
//  Proj1_StormViewer_new
//
//  Created by 수현 on 2021/11/06.
//

import UIKit

class ViewController: UITableViewController {
    var pictures = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let fm = FileManager.default
        let path = Bundle.main.resourcePath!
        let items = try! fm.contentsOfDirectory(atPath: path)
        for item in items {
            if item.hasPrefix("nssl") {
                let idxBeforeDot = item.count - 4
                let endIdx: String.Index = item.index(item.startIndex, offsetBy: idxBeforeDot)
                pictures.append(String(item[..<endIdx]))
            }
        }
    
        tableView.register(CustomTableViewCell.nib(), forCellReuseIdentifier: CustomTableViewCell.identifier)
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pictures.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CustomTableViewCell.identifier, for: indexPath) as! CustomTableViewCell
        cell.configure(with: pictures[indexPath.row], imageName: pictures[indexPath.row])
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
}

//class customCell: UITableViewCell {
//
//    let cellImageView: UIImageView = {
//        let cellImageView = UIImageView()
//        cellImageView.translatesAutoresizingMaskIntoConstraints = false
//        return cellImageView
//    }()
//
//    let imageNameLbl: UILabel = {
//        let imageNameLbl = UILabel()
//        imageNameLbl.translatesAutoresizingMaskIntoConstraints = false
//        imageNameLbl.font = UIFont.boldSystemFont(ofSize: 20)
//        return imageNameLbl
//    }()
//
//    private func addContentView() {
//        contentView.addSubview(cellImageView)
//        contentView.addSubview(imageNameLbl)
//    }
//
//    private func autoLayout() {
//        let margin: CGFloat = 10
//        NSLayoutConstraint.activate([
//            cellImageView.topAnchor.constraint(equalTo: self.topAnchor),
//            cellImageView.leadingAnchor.constraint(equalTo: self.leadingAnchor),
//            cellImageView.widthAnchor.constraint(equalToConstant: 130),
//            cellImageView.heightAnchor.constraint(equalToConstant: 80),
//
//            imageNameLbl.topAnchor.constraint(equalTo: self.topAnchor),
//            imageNameLbl.leadingAnchor.constraint(equalTo: cellImageView.trailingAnchor, constant: margin),
//            imageNameLbl.trailingAnchor.constraint(equalTo: self.trailingAnchor)
//        ])
//    }
//
//    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
//        super.init(style: style, reuseIdentifier: reuseIdentifier)
//        addContentView()
//        autoLayout()
//    }
//
//    required init?(coder: NSCoder) {
//        super.init(coder: coder)
//    }
//
//}
