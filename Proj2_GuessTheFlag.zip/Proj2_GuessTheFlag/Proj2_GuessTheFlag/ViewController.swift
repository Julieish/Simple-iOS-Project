//
//  ViewController.swift
//  Proj2_GuessTheFlag
//
//  Created by 수현 on 2021/11/11.
//

import UIKit

class ViewController: UIViewController {
    
    var countries = [String]()
    var score = 0
    var correctAnswer = 0
    var questionAsked = 0
    
    @IBOutlet weak var btn1: UIButton!
    @IBOutlet weak var btn2: UIButton!
    @IBOutlet weak var btn3: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        countries += ["estonia", "france", "germany", "ireland", "italy", "monaco", "nigeria", "poland", "russia", "spain", "uk", "us"]
//        let fm = FileManager.default
//        let path = Bundle.main.resourcePath!
//        let items = try! fm.contentsOfDirectory(atPath: path)
//
//        for item in items {
//            if item.contains("@") {
//                let itemArr = Array(item)
//                let idx = itemArr.firstIndex(of: "@")!
//                let name = String(itemArr[0..<idx])
//                if !countries.contains(name) {
//                    countries.append(name)
//                }
//            }
//        }
//        print(countries)
        
        btn1.layer.borderWidth = 1
        btn2.layer.borderWidth = 1
        btn3.layer.borderWidth = 1
        
//        btn1.layer.borderColor = UIColor(red: 1.0, green: 0.6, blue: 0.2, alpha: 1.0).cgColor
//        btn2.layer.borderColor = UIColor(red: 1.0, green: 0.6, blue: 0.2, alpha: 1.0).cgColor
//        btn3.layer.borderColor = UIColor(red: 1.0, green: 0.6, blue: 0.2, alpha: 1.0).cgColor
        
        
        askQuestion(action: nil)
    }
    
    func askQuestion(action: UIAlertAction!) {
        countries.shuffle()
        btn1.setImage(UIImage(named: countries[0]), for: .normal)
        btn2.setImage(UIImage(named: countries[1]), for: .normal)
        btn3.setImage(UIImage(named: countries[2]), for: .normal)
        
        correctAnswer = Int.random(in: 0...2)
        questionAsked += 1
        title = countries[correctAnswer].uppercased()
    }
    
    func endOfTheGame(action: UIAlertAction!) {
        let endAc = UIAlertController(title: "End of the Game", message: "Your final score is \(score)", preferredStyle: .alert)
        endAc.addAction(UIAlertAction(title: "Exit", style: .destructive, handler: nil))
        endAc.addAction(UIAlertAction(title: "Restart", style: .default, handler: askQuestion))
//        self.presentedViewController?.present(endAc, animated: true)
        present(endAc, animated: true)
    }
    
    @IBAction func tapBtn(_ sender: UIButton) {
        var title: String
        
        if sender.tag == correctAnswer {
            title = "Correct!"
            score += 1
        } else {
            title = "Wrong! That's the flag of \(countries[sender.tag].uppercased())"
            score -= 1
        }
        self.title = String("Your score : \(score)")
        let ac = UIAlertController(title: title, message: "Your Score is \(score)", preferredStyle: .alert)
        
        if questionAsked >= 10 {
            questionAsked = 0
            score = 0
            print(correctAnswer)
            ac.addAction(UIAlertAction(title: "Continue", style: .default, handler: endOfTheGame))
            present(ac, animated: true)
            
        } else {
            ac.addAction(UIAlertAction(title: "Continue", style: .default, handler: askQuestion))
            present(ac, animated: true)
        }
    }
    
}

