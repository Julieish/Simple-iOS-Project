//
//  SecondViewController.swift
//  TransmissionByNavigationController
//
//  Created by 수현 on 2021/10/30.
//

import UIKit

class SecondViewController: UIViewController {
    
    @IBOutlet weak var txtLbl: UILabel!
    var str: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let string = str {
            txtLbl.text = string
        } else {
            txtLbl.text = ""
        }
    }
    
    @IBAction func tapBackBtn(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
}
