//
//  FirstViewController.swift
//  TransmissionByNavigationController
//
//  Created by 수현 on 2021/10/30.
//

import UIKit

class FirstViewController: UIViewController {

    @IBOutlet weak var txtField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func tapSendTextBtn(_ sender: UIButton) {
        guard let vc = storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as? SecondViewController  else {
            return }
        vc.str = txtField.text!
        self.navigationController?.pushViewController(vc, animated: true)
    }
    

}
