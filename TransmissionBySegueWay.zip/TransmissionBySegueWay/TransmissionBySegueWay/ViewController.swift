//
//  ViewController.swift
//  TransmissionBySegueWay
//
//  Created by 수현 on 2021/10/30.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func tapSendBtn(_ sender: UIButton) {
        print("Segueway activated!")
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? SecondViewController {
            vc.str = txtField.text!
            vc.modalPresentationStyle = .fullScreen
        }
    }
}

