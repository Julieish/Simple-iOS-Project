//
//  SecondViewController.swift
//  TransmissionBySegueWay
//
//  Created by 수현 on 2021/10/30.
//

import UIKit

class SecondViewController: UIViewController {
    
    var str: String?
    @IBOutlet weak var txtLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let txt = str {
            txtLbl.text = txt
        } else {
            txtLbl.text = ""
        }
    }
    
    @IBAction func tapBackBtn(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
}
