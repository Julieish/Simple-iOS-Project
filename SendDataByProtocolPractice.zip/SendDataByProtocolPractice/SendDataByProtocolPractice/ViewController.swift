//
//  ViewController.swift
//  SendDataByProtocolPractice
//
//  Created by 수현 on 2021/11/13.
//

import UIKit


class ViewController: UIViewController, sendDataDelegate {
    @IBOutlet weak var label: UILabel!
    
    func updateLabelText(text: String) {
        label.text = text
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func tapBtn(_ sender: UIButton) {
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "InsertViewController") as? InsertViewController else { return }
        vc.modalPresentationStyle = .fullScreen
        vc.del = self
        self.present(vc, animated: true, completion: nil)
    }
    

}

